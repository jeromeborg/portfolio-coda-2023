-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 192.168.56.56
-- Généré le : ven. 17 nov. 2023 à 03:49
-- Version du serveur : 8.0.31-0ubuntu0.20.04.2
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `portfolio`
--
CREATE DATABASE IF NOT EXISTS `portfolio` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `portfolio`;

-- --------------------------------------------------------

--
-- Structure de la table `cl_partners`
--

DROP TABLE IF EXISTS `cl_partners`;
CREATE TABLE `cl_partners` (
  `id` int NOT NULL,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `logo` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `pudated_at` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `cl_partners`
--

INSERT INTO `cl_partners` (`id`, `name`, `logo`, `link`, `is_active`, `created_at`, `pudated_at`) VALUES
(1, 'ENVATO', 'logo-1.png', 'https://www.envato.com', 1, '2023-10-22 13:20:47', '0000-00-00 00:00:00'),
(2, 'woocommerce', 'logo-2.png', 'https://www.woocommerce.com', 1, '2023-10-22 13:20:47', '0000-00-00 00:00:00'),
(3, 'wordpress', 'logo-3.png', 'https://www.wordpress.com', 1, '2023-10-22 13:21:59', '0000-00-00 00:00:00'),
(4, 'magento', 'logo-4.png', 'https://www.magento.com', 1, '2023-10-22 13:21:59', '0000-00-00 00:00:00'),
(5, 'sass-lang', 'logo-5.png', 'https://www.sass-lang.com', 1, '2023-10-22 13:22:45', '0000-00-00 00:00:00'),
(6, 'pingdom', 'logo-6.png', 'https://www.pingdom.com', 0, '2023-10-22 13:22:45', '2023-10-23 11:28:10'),
(7, 'lesscss', 'logo-7.png', 'https://www.lesscss.org', 1, '2023-10-22 13:23:43', '0000-00-00 00:00:00'),
(8, 'jquery', 'logo-8.png', 'https://www.jquery.com', 1, '2023-10-22 13:23:43', '0000-00-00 00:00:00');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cl_partners`
--
ALTER TABLE `cl_partners`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cl_partners`
--
ALTER TABLE `cl_partners`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
